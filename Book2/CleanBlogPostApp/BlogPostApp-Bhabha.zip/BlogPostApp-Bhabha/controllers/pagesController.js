module.exports = {
    about: (req, res) => {
        res.render("about");
      },
    
      contact: (req, res) => {
        res.render("contact");
      },

      
}